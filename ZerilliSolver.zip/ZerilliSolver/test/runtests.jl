using Test
using Zerilli

@testset "Zerilli_Testss.jl" begin
    @test Zerilli.InitialData.rstar(1.0,1.0) == 0

    @test Zerilli.InitialData.r(Zerilli.InitialData.rstar(1.0,1.0),1.0) == 1

    @test Zerilli.InitialData.drG(1,3,1,1,1,2) ==0

    @test Zerilli.InitialData.dtGaussian1D(1, 1, 1, 1) == 1

    @test Zerilli.InitialData.InitialPsiValues(0, 3, 1, 1, 1, 2) == 0
    # Write your tests here.
end
#you can run this best in the terminal when activated environment
#Note that floats and integers are not the same, should be floating point both sides


#half a resolution, cfl, run equation solver, h, h2, h4
# 10 minutes, c_fl = 0.3
#tf =20

#extraction at different radii
#on the domain the potential should be small