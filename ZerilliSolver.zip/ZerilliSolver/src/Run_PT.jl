module Run_PT

using ..InitialData
using ..Integrator_PT
using ..ODE_PT
using GridFunctions

export run_zerilli_PT

function run_zerilli_PT(domain::Vector, ncells::Integer,
    tf::Real, cfl::Real, l::Integer, M::Real=1.0, P::Real=1.0, L::Real=1.0;
                 boundary_type::Symbol=:radiative,
                 folder="", save_every=1)

    @assert boundary_type === :radiative || boundary_type === :reflective

    grid = UniformGrid(domain, ncells)

    N = ncells + 1
    nt = ceil(Int64, tf / (cfl * spacing(grid)))
    t = UniformGrid([0.0, tf], nt)
    rnor = InitialData.r.(coords(grid),Ref(M))
    #Ref keeps it fixed that you don't also iterate over M

    # gridrnorm= UniformGrid(InitialData.r(domain,M), ncells)
    # rnor = coords(gridrnorm)


    #Original paper
    Ψ = InitialData.Poschl_Teller.(Ref(0.0), rnor, Ref(l), Ref(l))
    Π = InitialData.dtPoschl_Teller.(Ref(0.0), rnor,  Ref(l), Ref(l))
    Φ = InitialData.drPoschl_Teller.(Ref(0.0), rnor, Ref(l), Ref(l))


    params = (h=spacing(grid), N=N, bc=boundary_type, t=t, ti=coords(t),
              dt=spacing(t), save_every=save_every, M=M, grid=grid,
              folder=folder, cfl=cfl, rcoord=coords(grid), l=l, P=P, L=L)
    statevector = hcat(Φ, Π, Ψ)
    Integrator_PT.solve_PT(ODE_PT.rhs!_PT, statevector, params)
    return nothing
end


end # end of module
