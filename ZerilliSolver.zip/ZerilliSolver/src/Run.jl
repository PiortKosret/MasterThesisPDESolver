module Run

using ..InitialData
using ..Integrator
using ..ODE
using GridFunctions

export run_zerilli

function run_zerilli(domain::Vector, ncells::Integer,
    tf::Real, cfl::Real, l::Integer, M::Real=1.0, P::Real=1.0, L::Real=1.0;
                 boundary_type::Symbol=:radiative,
                 folder="", save_every=1)

    @assert boundary_type === :radiative || boundary_type === :reflective

    grid = UniformGrid(domain, ncells)

    N = ncells + 1
    nt = ceil(Int64, tf / (cfl * spacing(grid)))
    t = UniformGrid([0.0, tf], nt)
    rnor = InitialData.r.(coords(grid),Ref(M))
    #Ref keeps it fixed that you don't also iterate over M

    # gridrnorm= UniformGrid(InitialData.r(domain,M), ncells)
    # rnor = coords(gridrnorm)

    # Initial Data
    # w1 = 2.5
    # w2 = 2.1
    # r0 = -20 #2.0*M + 3.0*M
    # mu= 2
    # omega = (mu / (sqrt(2)))  #you can change this to value in between 1 and \lambda=l 

    # Φ = InitialData.QNM1D.(0, rnor, w1, w2, r0)
    # Π = InitialData.dtQNM1D.(0, rnor, w1, w2, r0)
    # Ψ = InitialData.drQNM1D.(0, rnor, w1, w2, r0)
    
    # n_scaling = 20

    # σ = 6
    
    # Φ = InitialData.Gaussian1D.(0, coords(grid), σ, r0) #to take without transofrmation I made rnor now grid coords(grid)
    # Π = InitialData.dtGaussian1D.(0, coords(grid), σ, r0)
    # Ψ = InitialData.drGaussian1D.(0, coords(grid), σ, r0)

    #Zerilli paper CLAP
    
    # Φ = InitialData.PSI_zer.(Ref(0.0), rnor, Ref(M))
    # Π = InitialData.dtPSI_zer.(Ref(0.0), rnor, Ref(M))
    # Ψ = InitialData.drPSI_zer.(Ref(0.0), rnor, Ref(M))

    #Original paper
    # Φ = InitialData.PSI_GNPP.(Ref(0.0), rnor, Ref(M), Ref(L))
    # Π = InitialData.dtPSI_GNPP.(Ref(0.0), rnor, Ref(M), Ref(L), Ref(P))
    # Ψ = InitialData.drPSI_GNPP.(Ref(0.0), rnor, Ref(M), Ref(L))

    #simple SimplePDE 
    # Φ = InitialData.SimplePDE.(Ref(0.0), coords(grid), Ref(r0))
    # Π = InitialData.dtSimplePDE.(Ref(0.0), coords(grid), Ref(r0))
    # Ψ = InitialData.drSimplePDE.(Ref(0.0), coords(grid), Ref(r0))

    #simple SimplePDE 2
    # Φ = InitialData.SimplePDE2.(Ref(0.0), coords(grid), Ref(r0))
    # Π = InitialData.dtSimplePDE2.(Ref(0.0), coords(grid), Ref(r0))
    # Ψ = InitialData.drSimplePDE2.(Ref(0.0), coords(grid), Ref(r0))

    #Poschl Teller test 
    # Φ = InitialData.Poschl_Teller4.(Ref(0.0), coords(grid), Ref(l), Ref(mu)) #Might have found the error here: grid transfromation!!!!!
    # Π = InitialData.dtPoschl_Teller4b.(Ref(0.0), coords(grid), Ref(l), Ref(mu))
    # Ψ = InitialData.drPoschl_Teller4.(Ref(0.0), coords(grid), Ref(l), Ref(mu))

    #simple line test
    # Φ = InitialData.SimpleLine.(Ref(0.0), coords(grid))
    # Π = InitialData.trSimpleLine.(Ref(0.0), coords(grid))
    # Ψ = InitialData.drSimpleLine.(Ref(0.0), coords(grid))

    # Φ = InitialData.SimpleLine.(Ref(0.0), rnor)
    # Π = InitialData.trSimpleLine.(Ref(0.0), rnor)
    # Ψ = InitialData.drSimpleLine.(Ref(0.0), rnor)

    Φ = InitialData.InitialPsiValues.(Ref(0.0), rnor, Ref(M), Ref(P), Ref(L), Ref(l))
    Π = InitialData.dtInitialPsiValues.(Ref(0.0), rnor, Ref(M), Ref(P), Ref(L), Ref(l))
    Ψ = InitialData.drInitialPsiValues.(Ref(0.0), rnor, Ref(M), Ref(P), Ref(L), Ref(l))
    
    # Ψ = InitialData.drInitialPsiValues_2.(Ref(0.0), rnor, Ref(M), Ref(P), Ref(L), Ref(l))

    params = (h=spacing(grid), N=N, bc=boundary_type, t=t, ti=coords(t),
              dt=spacing(t), save_every=save_every, M=M, grid=grid,
              folder=folder, cfl=cfl, rcoord=coords(grid), l=l, P=P, L=L) # mu=mu,   omega = omega, r0 = r0, n_scaling = n_scaling
    statevector = hcat(Φ, Π, Ψ)
    Integrator.solve(ODE.rhs!, statevector, params)
    return nothing
end




end # end of module
