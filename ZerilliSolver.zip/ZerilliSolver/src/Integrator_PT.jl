module Integrator_PT

using HDF5
using LoopVectorization
using ..InitialData


const proj_path = pkgdir(Integrator_PT)
const output_path = string(proj_path, "/output/")

function get_iter_str(i, N)
    i = string(i)
    while length(i) < length(string(N))
        i = string("0", i)
    end
    if length(i) <= 2
        return string("0", i)
    else
        return i
    end
end

function base_path(folder)
    return string(output_path, folder)
end

function sims_path(folder)
    return string(output_path, folder, "/sims/")
end

@inline function RK4(rhs!_PT::F, dt::Real, reg1, reg2, reg3, reg4, params, t::Real,
    indices::CartesianIndices) where {F} #seems like he is not using the normal one as before
    rhs!_PT(reg4, reg1, params, t) #takes in the initial condition and then give the time derivative of what you should have
    @inbounds @fastmath @avx for i in indices
        reg3[i] = dt * reg4[i] #you take dt so that you have the step size h
        reg1[i] = reg1[i] + reg3[i] / 2 #for i you then pick you had before which is y_n and then pick k_1 h/2, so this is k_2
        reg2[i] = reg3[i] #make reg 2 the same as dt * k_1 (why??)
    end 
    rhs!_PT(reg4, reg1, params, t) #again gives you the time derivatives, but uses the k_2 apporximatoin?
    @inbounds @fastmath @avx for i in indices 
        reg3[i] = dt * reg4[i] 
        reg1[i] = reg1[i] + (reg3[i] - reg2[i]) / 2  #takes what we had as k_2, give you a new k_3 and takes away the old k_3 aproximation and divides by 2
    end
    rhs!_PT(reg4, reg1, params, t)
    @inbounds @fastmath @avx for i in indices
        reg3[i] = dt * reg4[i] - reg3[i] / 2 #takes the new aproximation for the time derivative, and then takes of the old aproximation of the time derivative and divides that by 2
        reg1[i] = reg1[i] + reg3[i] #the old aproximation of reg1 is now given by the new time derivative
        reg2[i] = reg2[i] / 6 - reg3[i] #reg 2 stil is the one approcimation of the original dt*k1, which now is divided by 6 to then have the new aproximatoin taken of
    end
    rhs!_PT(reg4, reg1, params, t)
    @inbounds @fastmath @avx for i in indices
        reg3[i] = dt * reg4[i] + reg3[i] + reg3[i] #new aproximation, adding two times the old one (why?)
        reg1[i] = reg1[i] + reg2[i] + reg3[i] / 6 #reg 1 which is supposed to be your initial data that you use later, is given by old data + the new reg2 stuff and then adding the reg3 aproximation
    end
    return nothing
end


#okay I need to check how this works, most likely reg1 changes s.t. the input changes, e.g. f(...) changes and then in the end reg1 is all gucci. 
#also, I need to check the coordinate stuff, bc it worked fine before hand, we need to check what went wrong 

#plot reg1 and reg4 for the different r's to see if it is indeed time derivative

    #check if I put l=3 if all is zero, checked, it is indeed ero



function solve_PT(rhs_PT, statevector, params)
    nt = params.t.ncells + 1
    istr = get_iter_str(0, nt)
    base_dir = base_path(params.folder)
    sims_dir = sims_path(params.folder)

    base_str = string(sims_dir, "output_M=", params.M, "_L=", Int64(params.grid.domain[2]), "_nc=$(params.grid.ncells)_ti=")
    dataset = string(base_str, istr, ".h5")

    if !isdir(sims_dir)
        mkdir(base_dir)
        mkdir(sims_dir)
    end

    if isfile(dataset)
        rm(dataset)
    end

    print("Writing initial data at: ", dataset)
    h5write(dataset, "Phi", statevector[:, 1])
    h5write(dataset, "Pi", statevector[:, 2])
    h5write(dataset, "Psi", statevector[:, 3])
    # h5write(dataset, "Phi_hor_1", statevector[1, 1])
    # h5write(dataset, "Phi_hor_2", statevector[2, 1])
    # h5write(dataset, "Phi_far_1", statevector[params.grid.ncells, 1])
    # h5write(dataset, "Phi_far_2", statevector[params.grid.ncells - 1, 1])
    # h5write(dataset, "Pi_hor_1", statevector[1, 2])
    # h5write(dataset, "Pi_hor_2", statevector[2, 2])
    # h5write(dataset, "Pi_far_1", statevector[params.grid.ncells, 2])
    # h5write(dataset, "Pi_far_2", statevector[params.grid.ncells - 1, 2])
    println("✅")
    println("=========Starting time integration=========")

    print("Allocating registers for time integrator...")
    reg2 = similar(statevector)
    reg3 = similar(statevector)
    reg4 = similar(statevector)
    println("✅")

    println("saving every=", params.save_every)

    dt = params.dt
    indices = CartesianIndices(statevector)
    write_metadata(base_dir, params, dataset)
    RK4(rhs_PT, dt, reg2, reg2, reg3, reg4, params, 0.0, indices) #here reg1= reg2 is taken, maybe this is the problem
    @time RK4(rhs_PT, dt, reg2, reg2, reg3, reg4, params, 0.0, indices)  #here reg1= reg2 is taken, maybe this is the problem #changing it does not change anything wrt the result
    for (i, ti) in enumerate(params.ti)
        if ti == 0.0
            continue
        end
        println("Iteration = ", i, "/", nt)
        @time RK4(rhs_PT, dt, statevector, reg2, reg3, reg4, params, ti, indices)
        if i % params.save_every == 0
            istr = get_iter_str(i, nt)
            dataset = string(base_str, istr, ".h5")
            h5open(dataset, "w") do file
                write(file, "Phi", statevector[:, 1])
                write(file, "Pi", statevector[:, 2])
                write(file, "Psi", statevector[:, 3])
                # write(file, "Phi_hor_1", statevector[1, 1])
                # write(file, "Phi_hor_2", [i,statevector[2, 1]])
            #     write(file, "Phi_far_1", [i, statevector[4000, 1]])
            #     write(file, "Phi_far_2", statevector[params.grid.ncells-1, 1])
            #     write(file, "Pi_hor_1", statevector[1, 2])
            #     write(file, "Pi_hor_2", [i, statevector[2, 2]])
            #     write(file, "Pi_far_1", [i,statevector[4000, 2]])
            #     write(file, "Pi_far_2", statevector[params.grid.ncells-1, 2])
            end
        end
    end
    return nothing
end

function write_metadata(md_path, params, simdir)
    metadata_filename = string(md_path, "/metadata.yaml")
    data = "Grid:
    domain in r_star:       [$(params.grid.domain[1]), $(params.grid.domain[2])]
    domain in r:            [$(InitialData.r(params.grid.domain[1],params.M)), $(InitialData.r(params.grid.domain[2],params.M))]
    ncells:                 $(params.grid.ncells)
    dx:                     $(params.h)

    Time:
    CFL:          $(params.dt/params.h)
    domain:       [0.0, $(params.ti[end])]
    ncells:       $(length(params.ti)-1)
    dt:           $(params.dt)

    Input: 
    Mass:          $(params.M)    
    l-value:       $(params.l) 
    Momentum:      $(params.P) 
    Distance:      $(params.L) 
    r_0:           5 M

    Output:
    output path:   $simdir
    save every:    $(params.save_every)

    function:       (exp(-(r - r0)) + exp(r - r0)) * (exp(-t) + exp(t))
 
    \n
    "
    println(data)
    open(metadata_filename, "w") do file
        write(file, data)
    end
end

end #end of module
 

#Potentiaal veranderen -> reproduceren?
#potentiaal nul -> oplossen en vergelijken (want dan kan je kijken of je twee keer reg2 moet pakken of niet)

#qua presentatie: hoe het eruit zou moeten zien, hoe verschilt