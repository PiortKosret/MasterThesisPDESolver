module InitialData

using ForwardDiff
using LambertW
using LegendrePolynomials

#Defining coordinates
#Checked the code and it makes sense
function rstar(r ::Real, M ::Real)   
    return r + 2M * log(abs(r / (2*M) - 1.0))
end

function r(rstar::Real, M::Real)
    return 2*M *(1.0 + lambertw(exp(-1.0 + rstar / (2M))))
end

#creating general functions for my data
@inline function Lamb(l, r::Real, M::Real)
    return (l - 1.0) * (l + 2.0) + 6M / r
end
@inline function f(r::Real, M::Real)
    return 1.0 - 2M / r
end
@inline function mul(l)
    return (l - 1.0) * (l + 2.0)
end

@inline function delta_GNPP(r::Real, M::Real, l)
    return (Lamb(l, r, M) * r + 3.0 * M)
end

#ToyFunctions
@inline 
    @inline function Gaussian1D(t::Real, r::Real, σ::Real, r0::Real)
        return exp(-(r - r0 - t)^2 / σ^2)
    end

    @inline function dtGaussian1D(t::Real, r::Real, σ::Real, r0::Real)
        return ForwardDiff.derivative(t1 -> Gaussian1D(t1, r, σ, r0), t)
    end

    @inline function drGaussian1D(t::Real, r::Real, σ::Real, r0::Real)
        return ForwardDiff.derivative(r1 -> Gaussian1D(t, r1, σ, r0), r)
    end
#

#ToyFunctions2
@inline
    @inline function QNM1D(t::Real, r::Real, w1::Real, w2::Real, r0::Real)
        return exp(-(r - r0 - w1 * t)) * cos(w2 * t)
    end

    @inline function dtQNM1D(t::Real, r::Real, w1::Real, w2::Real, r0::Real)
        return ForwardDiff.derivative(t1 -> QNM1D(t1, r, w1, w2, r0), t)
    end

    @inline function drQNM1D(t::Real, r::Real, w1::Real, w2::Real, r0::Real)
        return ForwardDiff.derivative(r1 -> QNM1D(t, r1, w1, w2, r0), r)
    end
#

#simple line 
@inline
    @inline function SimpleLine(t::Real, r::Real)
        return r
    end

    @inline function dtSimpleLine(t::Real, r::Real)
        return ForwardDiff.derivative(t1 -> SimpleLine(t1, r), t)
    end

    @inline function drSimpleLine(t::Real, r::Real)
        return ForwardDiff.derivative(r1 -> SimpleLine(t, r1), r)
    end

#

#ToyFunctions3
@inline
    @inline function SimplePDE(t::Real, r::Real,  r0::Real)
        return exp(-(r - r0 - t)) + exp(r - r0 -  t)
    end

    @inline function dtSimplePDE(t::Real, r::Real,  r0::Real)
        return ForwardDiff.derivative(t1 -> SimplePDE(t1, r, r0), t)
    end

    @inline function drSimplePDE(t::Real, r::Real,  r0::Real)
        return ForwardDiff.derivative(r1 -> SimplePDE(t, r1, r0), r)
    end
#

#ToyFunctions4
@inline
    @inline function SimplePDE2(t::Real, r::Real, r0::Real)
        return (exp(-(r - r0)) + exp(r - r0)) * (exp(-t) + exp(t))
    end

    @inline function dtSimplePDE2(t::Real, r::Real, r0::Real)
        return (exp(-(r - r0)) + exp(r - r0)) * (-exp(-t) + exp(t)) #ForwardDiff.derivative(t1 -> SimplePDE2(t1, r, r0), t)
    end

    @inline function drSimplePDE2(t::Real, r::Real, r0::Real)
        return (-exp(-(r - r0)) + exp(r - r0)) * (exp(-t) + exp(t)) #ForwardDiff.derivative(r1 -> SimplePDE2(t, r1, r0), r)
    end
#

#ToyFunctions Poschl-Teller
@inline
    @inline function P_l_m(r::Real, lamb::Integer, mu::Integer)
        if lamb==0
            return 1
        end
        if lamb==1
            if mu==0
                return r
            end
            if mu==1
                return -(1-r^2)^(1/2)
            end
        end
        if lamb==2
            if mu==0
                return 0.5*(3*r^2-1)
            end
            if mu==1
                return -3*r*(1-r^2)^(1/2)
            end
            if mu==2
                return 3*(1-r^2)
            end
        end
    end

    @inline function omega(mu::Integer)
        return mu /sqrt(2) #was mu^2/sqrt(2)
    end
    @inline function Poschl_Teller(t::Real, r::Real, lamb::Integer, mu::Integer)
        return Plm(tanh(r), lamb, mu)* exp(sqrt(2)*omega(mu) *t*im)
    end

    @inline function dtPoschl_Teller(t::Real, r::Real, lamb::Integer, mu::Integer)
        return ForwardDiff.derivative(t1 -> Poschl_Teller(t1, r, lamb, mu), t)
    end

    @inline function drPoschl_Teller(t::Real, r::Real, lamb::Integer, mu::Integer)
        return ForwardDiff.derivative(r1 -> Poschl_Teller(t, r1, lamb, mu), r)
    end

    @inline function Poschl_Teller2(t::Real, r::Real, lamb::Integer, mu::Integer)
        return P_l_m(tanh(r), lamb, mu) * exp(sqrt(2) * omega(mu) * t * im)
    end

    @inline function dtPoschl_Teller2(t::Real, r::Real, lamb::Integer, mu::Integer)
        return ForwardDiff.derivative(t1 -> Poschl_Teller(t1, r, lamb, mu), t)
    end

    @inline function drPoschl_Teller2(t::Real, r::Real, lamb::Integer, mu::Integer)
        return ForwardDiff.derivative(r1 -> Poschl_Teller(t, r1, lamb, mu), r)
    end 

    @inline function Poschl_Teller3(t::Real, r::Real, lamb::Integer, mu::Integer)
    return Plm(tanh(r), lamb, mu) *
           (cos(omega(mu)*t)) #Plm(tanh(r), lamb, mu)* (exp(sqrt(2)*omega(mu) *t*im) + exp(-sqrt(2)*omega(mu) *t*im))/2
    end

    @inline function dtPoschl_Teller3(t::Real, r::Real, lamb::Integer, mu::Integer)
        return ForwardDiff.derivative(t1 -> Poschl_Teller3(t1, r, lamb, mu), t)
    end

    @inline function drPoschl_Teller3(t::Real, r::Real, lamb::Integer, mu::Integer)
        return ForwardDiff.derivative(r1 -> Poschl_Teller3(t, r1, lamb, mu), r)
    end


    @inline function Poschl_Teller4(t::Real, r::Real, lamb::Integer, mu::Integer)
        return Plm(tanh(r), lamb, mu) * (exp(-omega(mu)*t * im))
    end

    @inline function dtPoschl_Teller4(t::Real, r::Real, lamb::Integer, mu::Integer)
        return -omega(mu) * Plm(tanh(r), lamb, mu) * (exp(-omega(mu) * t))
    end

    @inline function dtPoschl_Teller4b(t::Real, r::Real, lamb::Integer, mu::Integer)
        return 0 #ForwardDiff.derivative(t1 -> Poschl_Teller4(t1, r, lamb, mu), t)
    end

    @inline function drPoschl_Teller4(t::Real, r::Real, lamb::Integer, mu::Integer)
        return ForwardDiff.derivative(r1 -> Poschl_Teller4(t, r1, lamb, mu), r)
    end

    @inline function V_pot_Poschl_Teller(lamb ::Integer, r::Real)
        return lamb* (lamb+1)*sech(r)^2 /2
    end

    @inline function V_pot_Poschl_Teller2(lamb ::Integer, r::Real)
        return lamb* (lamb+1)*sech(r)^2 
    end

    @inline function V_pot_Poschl_Teller_adap(lamb ::Integer, r::Real, n::Real)
        return - lamb* (lamb+1)*sech(r)^2 /(2*n)
    end
#

#functions from GNPP paper
@inline
    @inline function PSI_GNPP(t::Real, r::Real, M::Real, L::Real)
        return 8.0*(M*L^2 *(5*sqrt(r-2.0*M)+ 7.0 * sqrt(r)  )r)/(3.0*(sqrt(r)+ sqrt(r-2.0*M))^5 * (2.0*r+3.0*M))
    end

    @inline function dtPSI_GNPP(t::Real, r::Real, M::Real, L::Real, P :: Real)
        return (sqrt(r-2.0*M)*P*L*(8.0*r + 6.0*M) ) /( r^(5/2)* (2.0 * r + 3.0 * M))
    end

    @inline function drPSI_GNPP(t::Real, r::Real, M::Real, L::Real)
        return ForwardDiff.derivative(r1 -> PSI_GNPP(t, r1, M, L), r)
    end

    @inline function V_pot_GNPP(l , r ::Real, M ::Real )
    return (1 - 2.0 * M / r) * ((4.0 * r / (delta_GNPP(r, M, l)^2)) *(72*M^3/r^5 - 12.0*M*mul(l)*(1-3.0*M/r)/r^3 ) + 2*mul(l)*l*(l+1)/r*delta_GNPP(r, M, l) )
    end
#

#function from Zerilli paper

@inline
    @inline function R_zer(r::Real, M::Real)
        return (sqrt(r) + sqrt(r-2.0*M))^2
    end

    @inline function lamb_zer( r ::Real, M:: Real)
        return 1.0 + 3.0*M / (2.0*r)
    end

    @inline function V_pot_zer(r:: Real, M:: Real)
        return (1-2.0*M/r)*(lamb_zer(r,M)^(-2) *(9.0*M^3/(2*r^5) - (3.0* M/r^3 ) *(1-3.0*M/r)) + 6.0/(r^2 * lamb_zer(r,M)))
    end

    @inline function g_zer(r::Real, M::Real)
        return M^3 / (8.0*R_zer(r,M)^3 * (1.0 + M/(2.0*R_zer(r,M))))
    end

    @inline function skrt_zer(r::Real, M::Real)
        return r*g_zer(r, M)/sqrt(1-2.0*M/r)
    end

    @inline function drskrt_zer(r::Real, M::Real)
        return ForwardDiff.derivative(r1 -> skrt_zer(r1, M), r)
    end

    @inline function Q1_zer(r::Real, M::Real)
        return 2.0 * r *
            (1.0 - 2.0 * M / r)^2 * (g_zer(r, M) / (1.0 - 2.0 * M / r) -
                (1 / sqrt(1.0 - 2.0 * M / r)) * drskrt_zer(r, M)) + 6.0 * r * g_zer(r, M)
    end

    @inline function PSI_zer(t::Real, r::Real, M::Real)
        return sqrt(4 * pi / 5) * Q1_zer(r, M) /lamb_zer(r, M)
    end

    @inline function dtPSI_zer(t::Real, r::Real, M::Real)
        return 0
    end

    @inline function drPSI_zer(t::Real, r::Real, M::Real)
        return ForwardDiff.derivative(r1 -> PSI_zer(t, r1, M), r)
    end
#



#defining the function
@inline
    @inline function H2(t::Real, r::Real, M::Real, P::Real, L::Real, l)
        if l ==0
            return 0.0
        end
        if l== 2
            return 16.0*M*(L^2)/(sqrt(r)*(sqrt(r)+sqrt(r-2.0*M))^5)
        end
        if l ==3
            return 0.0
        end
        if l==4
            return 0.0
        end
    end
    @inline function G(t::Real, r ::Real, M ::Real, P::Real, L ::Real, l )   
        if l ==0
            return 0.0
        end
        if l== 2
            return (4 *L^2*M)/( M^2 *(5 *r + sqrt(r* (-2.0 *M + r))) +  M *(-10.0 *r^2 - 6.0 *sqrt(r^3 *(-2.0 *M + r))) +  4.0* (r^3 + sqrt(r^5 * (-2.0 *M + r))) )
        end
        if l ==3
            return 0.0
        end
        if l==4
            return 0.0
        end
    end
    @inline function K(t::Real, r::Real, M::Real, P::Real, L::Real, l)
        if l ==0
            return 0.0
        end
        if l== 2
            return (4.0 *L^2*M)/( M^2 *(5.0*r + sqrt(r* (-2.0 *M + r))) +  M *(-10.0 *r^2 - 6.0 *sqrt(r^3 *(-2.0 *M + r))) +  4.0* (r^3 + sqrt(r^5 * (-2.0 *M + r))) )
        end
        if l ==3
            return 0.0
        end
        if l==4
            return 0.0
        end
    end
    @inline function h1(t::Real, r::Real, M::Real, P::Real, L::Real, l)
        if l ==0
            return 0.0
        end
        if l== 2
            return 0.0
        end
        if l ==3
            return 0.0
        end
        if l==4
            return 0.0
        end
    end
#

#variable for the extrensic curvature 
@inline
    @inline function KK(t::Real, r::Real, M::Real, P::Real, L::Real, l)
        if l == 0
            return 0.0
        end
        if l == 2
            return 5.0 * P * L / r^3 #Ask Tom since its not in Mathematica
        end
        if l == 3
            return 0.0
        end
        if l == 4
            return 0.0
        end
    end

    @inline function KG(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        if l == 0
            return 0.0
        end
        if l == 2
            return P * L / r^3
        end
        if l == 3
            return 0.0
        end
        if l == 4
            return 0.0
        end
    end
    @inline function Kh1(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        if l == 0
            return 0.0
        end
        if l == 2
            return 0.0
        end
        if l == 3
            return 0.0
        end
        if l == 4
            return 0.0
        end
    end
    @inline function KH2(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        if l == 0
            return 0.0
        end
        if l == 2
            return -4.0 * P * L / r^3
        end
        if l == 3
            return 0.0
        end
        if l == 4
            return 0.0
        end
    end
#
#l , t, r, M, P, L, l
#  P * L / r^3 - P * L^3 * 96 / (r^3 * 7 * (sqrt(r - 2 * M) + sqrt(r))^4)


#defining the relevant derivatives for the gauge invariant stuff

@inline
    @inline function drG(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return ForwardDiff.derivative(r1 -> G(t, r1, M, P, L, l), r)
    end
    # println(drG(1,3,1,1,1,2))

    @inline function drdrG(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return ForwardDiff.derivative(r1 -> drG(t, r1, M, P, L, l), r)
    end
    #note dtG is not general but based on gauge choice such that perturbative lapse and shift =0
    @inline function dtG(t::Real, r::Real, M::Real, P::Real, L::Real, l)    
        return 2.0 *sqrt(1-2*M/r) *KG(t, r, M, P, L, l)
    end

    @inline function drh1(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return ForwardDiff.derivative(r1 -> h1(t, r1, M, P, L, l), r)
    end

    #I need to write down the christoffel symbols to write down the covariant derivative
    @inline function Christ(params, r , M )   
        if params == ["r", "r", "r"]
            return -(M / r^2) / (1 - 2 * M / r)
        end
        if params == ["r", "t", "t"]
            return (M / r^2) * (1 - 2 * M / r)
        end
        if params == ["t", "r", "t"]
            return (M / r^2) / (1 - 2 * M / r)
        end
        if params == ["t", "t", "r"]
            return (M / r^2) / (1 - 2 * M / r)
        else
            return 0
        end
    end

    #defining the relevant derivatives for the gauge invariant time derivative stuff
    #These are not working?
    @inline function drKG(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return ForwardDiff.derivative(r1 -> KG(t, r1, M, P, L, l), r)
    end

    @inline function drdrKG(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return ForwardDiff.derivative(r1 -> drKG(t, r1, M, P, L, l), r)
    end

    @inline function dtKG(t::Real, r::Real, M::Real, P::Real, L::Real, l)    #this is problematic
        return ForwardDiff.derivative(t1 -> KG(t1, r, M, P, L, l), t)
    end

    @inline function drKh1(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return ForwardDiff.derivative(r1 -> h1(t, r1, M, P, L, l), r)
    end


    #here I define the gauge invariant quantities 
    @inline function khat(l, t::Real, r::Real, M::Real, P::Real, L::Real)
        return K(t, r, M, P, L, l) + l * (l + 1) / 2 * G(t, r, M, P, L, l) - (2.0 / r) * h1(t, r, M, P, L, l) + r * +r * drG(t, r, M, P, L, l)
    end

    @inline function fhatrr(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return H2(t, r, M, P, L, l) - 2.0 * drh1(t, r, M, P, L, l) + 4.0 * drG(t, r, M, P, L, l) + r^2 * (drdrG(t, r, M, P, L, l) - Christ(["t", "r", "r"], r, M) * dtG(t, r, M, P, L, l) - Christ(["r", "r", "r"], r, M) * drG(t, r, M, P, L, l))
    end

    @inline function drKhat(l, t::Real, r::Real, M::Real, P::Real, L::Real)
        return ForwardDiff.derivative(r1 -> khat(l, t, r1, M, P, L), r)
    end

    #below is determined by gauge choice since perturbative lapse and shift are zero
    @inline function dtkhat(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return sqrt(1.0-2.0*M/r) * ( 2.0*KK(t, r, M, P, L, l) + ( l * (l + 1) + M/(r-2.0*M) ) * KG(t, r, M, P, L, l) - (4.0 / r) * Kh1(t, r, M, P, L, l) + r * +r * drKG(t, r, M, P, L, l) )
    end

    @inline function dtfhatrr(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return sqrt(1.0 - 2.0 * M / r)   * (KH2(t, r, M, P, L, l) - 2.0 * drKh1(t, r, M, P, L, l) + 4.0 * drKG(t, r, M, P, L, l) + r^2 * (drdrKG(t, r, M, P, L, l) + (M / (1.0 - 2.0 * M / r)) * drKG(t, r, M, P, L, l) + (M / (r - 2.0 * M)) * (-2.0 * Kh1(t, r, M, P, L, l) + 4.0 * KG(t, r, M, P, L, l) + r^2 * 2.0 * drKG(t, r, M, P, L, l) + (M / (1.0 - 2.0 * M / r)) * KG(t, r, M, P, L, l)) + (M*r^2 * (2.0*r-3.0*M)/(r-2*M)^4 ) * KG(t, r, M, P, L, l)))
    end

    @inline function drdtkhat(t::Real, r::Real, M::Real, P::Real, L::Real, l)
        return ForwardDiff.derivative(r1 -> dtkhat(t, r1, M, P, L, l ), r)
    end

#

#writing down the Zerilli function
@inline
    @inline function InitialPsiValues(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return 2.0 * r / (l * (l + 1)) * (khat(l, t, r, M, P, L) + 2.0 / (Lamb(l, r, M)) * f(r, M)^2 * fhatrr(t, r, M, P, L, l) - r * f(r, M) * drKhat(l, t, r, M, P, L))
    end

    @inline function drInitialPsiValues(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return ForwardDiff.derivative(r1 -> InitialPsiValues( t, r1, M, P, L, l), r)
    end

    @inline function drInitialPsiValues_2(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return  0
    end

    @inline function drdrInitialPsiValues(t::Real, r::Real, M::Real, P::Real, L::Real, l)
        return ForwardDiff.derivative(r1 -> drInitialPsiValues(t, r1, M, P, L, l), r)
    end

    @inline function dtInitialPsiValues(t::Real, r::Real, M::Real, P::Real, L::Real, l)   
        return (2.0*r)/(l*(l+1)) * (dtkhat(t, r, M, P, L, l) + 2.0/(Lamb(l,r,M)) *f(r, M)^2 * dtfhatrr(t, r, M, P, L, l) - r *f(r,M) * drdtkhat(t, r, M, P, L, l) )
    end
#

# Potential for the function
# THIS IS EVALUATED at r and not rstar
@inline function Vpot(l , r::Real , M::Real )   
    return f(r, M) / (Lamb(l, r, M)^2) * (mul(l)^2 * ((mul(l) + 2.0) / r^2 + 6.0 * M / r^3) + 36.0 * M^2 / r^4 * (mul(l) + 2.0 * M / r))
end




#T is for safety that is the same
end #end of module
